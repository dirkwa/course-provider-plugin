# Course Provider Plugin (WASM)

**Signal K server WASM plugin that provides Course data calculations.**

_Note: This is the WASM version of course-provider-plugin. It requires Signal K Server version 2.19.0+wasm or later with WASM plugin support._

---

## Features

This plugin computes navigation course data and populates the following paths under `navigation.course.calcValues`:

- `calcMethod` - Calculation type used (GreatCircle or Rhumbline)
- `bearingTrackTrue` - Bearing of track line relative to true north (rad)
- `bearingTrackMagnetic` - Bearing of track line relative to magnetic north (rad)
- `crossTrackError` - Distance from vessel to closest point on track (m)
- `previousPoint.distance` - Distance to previous waypoint (m)
- `distance` - Distance to next waypoint (m)
- `bearingTrue` - Bearing to next waypoint, true north (rad)
- `bearingMagnetic` - Bearing to next waypoint, magnetic north (rad)
- `velocityMadeGood` - Velocity component towards waypoint (m/s)
- `timeToGo` - Time to reach next waypoint (s)
- `estimatedTimeOfArrival` - ETA timestamp
- `targetSpeed` - Required speed to arrive at target time (m/s)
- `route.distance` - Total remaining route distance (m)
- `route.timeToGo` - Time to complete route (s)
- `route.estimatedTimeOfArrival` - Route ETA timestamp

Additionally:
- `performance.velocityMadeGoodToWaypoint` - VMG to current waypoint

## Notifications

The plugin raises the following notifications:

- **`notifications.navigation.course.arrivalCircleEntered`**: Alert when vessel enters the arrival circle defined by `navigation.course.nextPoint.arrivalCircle`

## HTTP API

The plugin exposes an HTTP endpoint:

```
GET /signalk/v2/api/vessels/self/navigation/course/calcValues
```

Returns the current calculated course values as JSON.

## Configuration

**Notifications:**
- **Enable sound:** Enable sound flag for notifications

**Calculation method:**
- **GreatCircle (default)**: Uses great circle calculations (shortest path on sphere)
- **Rhumbline**: Uses rhumb line calculations (constant bearing)

## Building

```bash
# Install dependencies
npm install

# Build WASM plugin
npm run build
```

The compiled plugin will be at `build/plugin.wasm`.

## Installation

### From npm (when published)

```bash
cd ~/.signalk
npm install @signalk/course-provider-wasm
```

### Manual Installation

1. Build the plugin (see above)
2. Copy the entire plugin directory to your Signal K plugins folder:
   ```bash
   cp -r course-provider-plugin ~/.signalk/node_modules/@signalk/course-provider-wasm
   ```
3. Restart Signal K Server
4. Enable the plugin in Server -> Plugin Config

## Required Signal K Paths

The plugin subscribes to:

- `navigation.position` - Vessel position (required)
- `navigation.course.nextPoint` - Destination waypoint (required)
- `navigation.course.previousPoint` - Origin waypoint (required)
- `navigation.magneticVariation` - For magnetic bearing calculations
- `navigation.speedOverGround` - For VMG/VMC calculations
- `navigation.courseOverGroundTrue` - For VMC calculations
- `navigation.course.arrivalCircle` - For arrival notification

## Migration from Node.js Version

This WASM version is functionally equivalent to the Node.js version. Key differences:

1. **Package name**: `@signalk/course-provider-wasm` (vs `@signalk/course-provider`)
2. **Build step**: Requires `npm run build` to compile AssemblyScript to WASM
3. **Performance**: WASM runs in sandbox with near-native performance
4. **Dependencies**: No runtime npm dependencies (geodesy library is built-in)

## License

Apache-2.0
